"""선택 검증 도구: Python Playwright와 Chromium 필요. 앱 실행에는 불필요."""
from pathlib import Path
import os
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':390,'height':844},offline=False)
    errors=[]
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.goto(os.environ.get('TEST_URL', 'http://127.0.0.1:8080/index.html'))
    page.context.set_offline(True)
    assert page.locator('.card').count()==10
    page.locator('#age').fill('78');page.locator('#town').select_option('옥산면')
    page.locator('[value=alone]').check();page.locator('button[type=submit]').click()
    assert 'A.' in page.locator('[data-id=ELD040]').inner_text()
    assert 'B.' in page.locator('[data-id=ELD022]').inner_text()
    page.locator('#tax').select_option('no');page.locator('#again').click()
    assert 'C.' in page.locator('[data-id=ELD004]').inner_text()
    page.locator('#tax').select_option('yes');page.locator('#again').click()
    assert 'A.' in page.locator('[data-id=ELD004]').inner_text()
    assert '예로 답했습니다' in page.locator('[data-id=ELD004]').inner_text()
    page.locator('[value=together]').check();page.locator('button[type=submit]').click()
    assert 'B.' in page.locator('[data-id=ELD040]').inner_text()
    for age,status in [('64','C.'),('65','A.')]:
        page.locator('#age').fill(age);page.locator('#town').select_option('의성읍');page.locator('button[type=submit]').click()
        assert status in page.locator('[data-id=ELD001]').inner_text()
    page.locator('#age').fill('-1');page.locator('button[type=submit]').click();assert '정수' in page.locator('#error').inner_text()
    page.locator('#age').fill('65');page.locator('button[type=submit]').click()
    c=page.locator('[data-id=ELD001]');c.locator('summary').first.click()
    # 권한 거절 상황으로 대체 경로 검증
    page.evaluate("Object.defineProperty(navigator, 'clipboard', {value: undefined, configurable: true})")
    c.get_by_role('button',name='상담할 내용 복사',exact=True).click()
    assert '자동 복사가 되지' in page.locator('#copyStatus').inner_text()
    assert 'ELD001 · 의성읍' in page.locator('#copyText').input_value()
    page.locator('#selectCopy').click();assert page.locator('#copyText').evaluate('(e)=>e.selectionEnd-e.selectionStart')>0
    page.locator('#closeCopy').click()
    for width in [320,390,768,1280]:
        page.set_viewport_size({'width':width,'height':900})
        for large in [False,True]:
            page.evaluate('(v)=>document.documentElement.classList.toggle("large",v)',large)
            assert page.evaluate('document.documentElement.scrollWidth<=window.innerWidth'),(width,large)
    page.locator('#search').fill('없는서비스');assert '검색 결과가 없습니다' in page.locator('#results').inner_text()
    page.locator('#search').fill('');page.locator('#all').click();assert '전체 안내 목록' in page.locator('#resultTitle').inner_text()
    page.locator('#category').select_option('건강');assert page.locator('.card').count()==3
    page.locator('#category').select_option('')
    page.emulate_media(media='print');assert page.locator('#inputSection').is_hidden()
    page.emulate_media(media='screen');page.set_viewport_size({'width':390,'height':844});page.evaluate('document.documentElement.classList.remove("large")')
    (root/'evidence').mkdir(exist_ok=True);page.screenshot(path=str(root/'evidence/mobile.png'),full_page=True)
    assert not errors,errors
    # 데이터 누락도 사용자에게 안내
    page.route('**/data.js',lambda route:route.abort())
    page.context.set_offline(False)
    page.reload();assert '데이터가 없거나 오류' in page.locator('#summary').inner_text()
    browser.close()
print('PASS: HTTP load + offline interaction, 10 groups, conditions, copy fallback, search/filter, 320–1280px + large text, print CSS, missing data')
