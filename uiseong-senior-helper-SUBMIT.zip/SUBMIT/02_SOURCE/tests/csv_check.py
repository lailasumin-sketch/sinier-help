import csv,json,subprocess,hashlib
from pathlib import Path
root=Path(__file__).resolve().parents[1]
p=root/'01_어르신생활돌봄.csv'
rows=list(csv.DictReader(p.open(encoding='utf-8-sig',newline='')))
data=json.loads(subprocess.check_output(['node','-e',"console.log(JSON.stringify(require('./data.js')))"],cwd=root,text=True))
expected=[dict(r,우선안내=r['우선안내']=='True') for r in rows]
assert data==expected, '원본 CSV와 data.js 불일치'
assert len(rows)==50 and len({r['서비스ID'] for r in rows})==50
assert len({r['서비스명'] for r in rows})==10
assert len({r['읍면'] for r in rows})==18
assert all(len(r)==12 and all(r.values()) for r in rows)
assert all(sum(x['서비스명']==r['서비스명'] for x in rows)==5 for r in rows)
assert [r['서비스ID'] for r in rows if r['읍면']=='옥산면']==['ELD004','ELD022','ELD040']
original=Path('/workspace/attachments/85ef4861-c82f-4250-8811-80683f9bb64d/01_어르신생활돌봄.csv')
if original.exists(): assert p.read_bytes()==original.read_bytes()
print('PASS CSV: 전체 50행·12열·모든 문자열·boolean·18읍면·10서비스 각5행·옥산면ID·원본 보존')
print('SHA256',hashlib.sha256(p.read_bytes()).hexdigest())
