# 의성 어르신 생활도우미

2026년 가상자료 기반 시제품. 실제 이용 가능 여부는 담당기관 확인이 필요합니다.

## 실행 / Windows USB

이 폴더 전체를 USB에 복사하고 `index.html`을 브라우저로 여세요. 설치·빌드·인터넷이 필요 없는 일반 HTML/CSS/JavaScript 구조입니다. data.js를 함께 두세요. ES module, fetch, 외부 CDN, 웹폰트, API는 사용하지 않습니다.

**Windows 및 file:// 실제 실행은 미검증입니다.** 이 환경의 Chromium 관리 정책이 file://를 차단했습니다. USB 복사본을 Windows Edge/Chrome에서 열어 조건 입력→추가 질문→상담→복사 대체→인쇄를 최종 확인하세요. USB 물리 복사도 미실행입니다.

개발 확인용 선택 명령: `python -m http.server 8080 --bind 127.0.0.1` (저장소 폴더에서 실행). 앱 실행 자체에는 Python/Node가 필요 없습니다.

## 파일

- index.html, styles.css, app.js: 화면·접근성·조건 입력·검색·필터·상담·복사·인쇄
- rules.js: UI와 분리된 순수 판정/묶음/정렬
- 01_어르신생활돌봄.csv: 첨부 원본 그대로 보존
- data.js: CSV에서 생성된 기본 데이터
- tools/generate_data.py: Python 표준 라이브러리 데이터 검증·생성 도구
- RULES.md: 원본 매핑과 명시적 판정표
- tests/: 판정 및 선택적 브라우저 검증
- evidence/mobile.png: 실제 Chromium 화면
- VALIDATION.md: 실행 증거와 미검증 범위

## 재생성 / 테스트

저장소 폴더에서:

```sh
python tools/generate_data.py
node --test tests/rules.test.js
```

브라우저 자동 검사(개발 검증에만 Playwright와 `/usr/bin/chromium` 필요): 위 HTTP 서버 실행 후 `python tests/browser_check.py`. 테스트 기본 주소는 로컬 HTTP이며 `TEST_URL`로 변경할 수 있습니다. 일반 사용자는 이 도구들을 설치할 필요가 없습니다.

## 사용 흐름

나이·읍면·가구 상황 입력 → 내게 맞는 안내 찾기 → 필요한 추가 질문의 예/아니요/모름 입력 → 다시 찾기 → 원본과 규칙 설명 확인 → 상담 방법 보기 → 상담할 내용 복사 또는 인쇄.

조건 수정 후 주 버튼을 다시 누르면 이유와 상태가 함께 바뀝니다. 전체 안내 검색은 조건별 결과와 구분됩니다. 다른 지역 참고자료는 선택 지역에서 제공된다는 뜻이 아닙니다. 전화번호·URL·준비서류·기간·금액은 원본에 없어 추정하지 않습니다.

복사 권한이 없으면 선택 가능한 텍스트 영역과 전체 선택 버튼이 나타납니다. 기기의 복사 기능 또는 Ctrl+C를 사용하세요. 큰 글씨 버튼·키보드 포커스·모바일 배치·인쇄 스타일이 있습니다. 실제 인쇄 장치, 스크린리더, Windows 브라우저는 추가 수동 점검 대상입니다.
