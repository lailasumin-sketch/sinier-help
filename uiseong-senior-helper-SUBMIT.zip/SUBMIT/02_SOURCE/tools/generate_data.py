"""CSV 원본을 검증하고 브라우저 일반 스크립트로 변환. 외부 패키지 불필요."""
import csv, json
from pathlib import Path
root = Path(__file__).resolve().parents[1]
headers = '서비스ID 읍면 서비스명 분야 대상조건_예시 안내내용 담당기관_유형 신청방식 접근성지원 우선안내 자료구분 기준연도'.split()
with (root / '01_어르신생활돌봄.csv').open(encoding='utf-8-sig', newline='') as f:
    reader = csv.DictReader(f)
    assert reader.fieldnames == headers, 'CSV 열 불일치'
    rows = list(reader)
assert len(rows) == 50 and len({r['서비스ID'] for r in rows}) == 50
assert len({r['서비스명'] for r in rows}) == 10
for row in rows:
    assert all(row.values()), '빈 값 발견'
    assert row['우선안내'] in ('True', 'False')
    row['우선안내'] = row['우선안내'] == 'True'
(root / 'data.js').write_text('// tools/generate_data.py로 생성. 원본 문자열 보존, 우선안내만 boolean 변환.\nconst SERVICE_DATA = ' + json.dumps(rows, ensure_ascii=False, indent=2) + ';\nif (typeof module !== "undefined") module.exports = SERVICE_DATA;\n', encoding='utf-8')
print('50행 / 고유 ID 50 / 서비스 10종 생성 완료')
