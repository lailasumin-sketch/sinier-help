"""정적 실행 파일·원본·검증 기록을 SUBMIT 폴더로 수집. ZIP은 검증 후 별도 생성."""
from pathlib import Path
import shutil
root=Path(__file__).resolve().parents[1]
target=root/'SUBMIT'
assert not target.exists(), '기존 SUBMIT 덮어쓰기 금지: 보존 후 새 패키지 경로를 사용하세요.'
run=target/'01_RUN';source=target/'02_SOURCE';evidence=target/'04_EVIDENCE'
for folder in [run,source,evidence]:folder.mkdir(parents=True)
files=['index.html','styles.css','data.js','rules.js','app.js']
for name in files:
 shutil.copy2(root/name,run/name)
 shutil.copy2(root/name,source/name)
for name in ['01_어르신생활돌봄.csv','README.md','RULES.md']:
 shutil.copy2(root/name,source/name)
for name in ['tools','tests']:shutil.copytree(root/name,source/name)
print('SUBMIT/01_RUN, 02_SOURCE, 04_EVIDENCE 생성')
