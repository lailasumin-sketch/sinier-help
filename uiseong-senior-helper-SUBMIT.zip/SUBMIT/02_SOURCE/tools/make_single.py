"""일반 스크립트와 CSS를 합친 복사·저장용 단일 HTML 생성."""
from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
html=(root/'index.html').read_text(encoding='utf-8')
html=html.replace('<link rel="stylesheet" href="styles.css">','<style>\n'+(root/'styles.css').read_text(encoding='utf-8')+'\n</style>')
for name in ['data.js','rules.js','app.js']:
    source=(root/name).read_text(encoding='utf-8')
    source=re.sub(r'</script',r'<\\/script',source,flags=re.I)
    html=html.replace('<script src="'+name+'"></script>','<script>\n'+source+'\n</script>')
(root/'OFFLINE.html').write_text(html,encoding='utf-8')
(root/'OFFLINE_COPY.txt').write_text(html,encoding='utf-8')
print('OFFLINE.html / OFFLINE_COPY.txt 생성 완료')
