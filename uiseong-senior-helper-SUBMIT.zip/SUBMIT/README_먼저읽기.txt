의성 어르신 생활도우미 — 전체 USB 제출 준비본

1. ZIP 전체를 한 폴더로 압축 해제하세요. index.html 하나만 꺼내면 안 됩니다.
2. 01_RUN 폴더에서 index.html을 Edge/Chrome으로 여세요.
   styles.css, data.js, rules.js, app.js가 같은 폴더에 있어야 합니다.
3. 앱 사용에는 인터넷, 로그인, Python, Node.js, 서버, 설치 또는 빌드가 필요 없는 구조입니다.
   단, 실제 Windows 및 file:// 실행은 미검증입니다.
   현재 클라우드 Chromium의 관리 정책이 file://를 차단했습니다.
   HTTP 로딩 후 네트워크 차단 상태의 핵심 동작은 통과했습니다.
4. 제출 전 Windows의 USB 복사본에서 인터넷을 끊고 새로고침·조건 입력·결과·상담 방법·복사·인쇄를 확인하세요.
5. 복사가 차단되면 표시된 내용을 전체 선택하고 Ctrl+C로 복사하세요.
6. 2026년 가상자료 시제품입니다. 실제 이용 가능 여부는 담당기관 확인이 필요합니다.

폴더:
01_RUN: 실행에 필요한 HTML/CSS/JS 전체 5파일
02_SOURCE: 동일 소스, 원본 CSV, 규칙 설명, 생성 도구, 테스트
04_EVIDENCE: 검증표, 알려진 한계, 브라우저 화면 및 실행 기록
발표자료는 포함하지 않습니다. 제작 완료를 주장하지 않습니다.

개발 검증(일반 사용자는 불필요):
02_SOURCE에서 python tests/csv_check.py
02_SOURCE에서 node --test tests/rules.test.js
데이터 재생성: python tools/generate_data.py (Python 표준 라이브러리)
브라우저 검증: Python Playwright와 /usr/bin/chromium이 있는 Linux 개발 환경에서
제출 최상위 폴더에서 python -m http.server 8080 --bind 127.0.0.1
별도 터미널의 02_SOURCE에서
TEST_URL=http://127.0.0.1:8080/01_RUN/index.html python tests/browser_check.py
개발 서버는 Ctrl+C로 종료합니다. Windows 사용자에게 이 도구 설치를 요구하지 않습니다.
