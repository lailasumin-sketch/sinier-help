/* UI와 독립된 순수 판정 함수. 원본 서비스명과 조건의 정확한 조합만 인식한다. */
const RULES = [
 ['기초연금 안내','만 65세 이상','age','만 나이 65세 이상인지 확인'],
 ['응급안전안심서비스 상담','독거 등 위험요인 상담','household','독거 외 다른 위험요인과 상담 필요 여부를 담당기관에 확인'],
 ['치매 조기검진 안내','검진 상담 희망자','screenInterest','검진 상담을 원하는지 확인'],
 ['노인맞춤돌봄 상담','돌봄 필요 여부 상담','careInterest','돌봄 상담을 원하는지 확인'],
 ['건강검진 일정 안내','해당 연도 검진 대상','screen','해당 연도 검진 대상 여부'],
 ['상수도 요금 조회 안내','상수도 사용자','water','상수도 사용 여부'],
 ['재산세 납부 안내','재산세 납세 대상','tax','재산세 납세 대상 여부'],
 ['폭염 안부 확인','폭염 취약 어르신','heat','폭염 취약 여부'],
 ['한파 대비 안내','한파 취약 어르신','cold','한파 취약 여부'],
 ['예방접종 안내','접종 대상 확인 필요','vaccine','접종 대상과 실제 접종 자격을 담당기관에 확인']
];
const STATUS = {A:'입력과 관련 있는 안내', B:'추가 확인이 필요한 안내', C:'제공된 예시 조건과 불일치'};
function validAge(value) { return /^\d+$/.test(String(value)) && Number(value) >= 0 && Number(value) <= 120; }
function assess(row, input) {
 const rule = RULES.find(r=>r[0]===row['서비스명'] && r[1]===row['대상조건_예시']);
 if (!rule) return {status:'B', reason:'인식하지 못한 원본 조건입니다.', checks:['원본 조건의 의미와 적용 여부를 담당기관에 확인']};
 const [, , key, question] = rule;
 let answer, reason;
 if(key==='age') { answer=validAge(input.age)?(Number(input.age)>=65?'yes':'no'):'unknown'; reason=answer==='yes'?'입력 나이가 예시의 만 65세 이상 조건에 부합합니다.':answer==='no'?'입력 나이는 만 65세 미만입니다.':'나이 확인이 필요합니다.'; }
 else if(key==='household') { answer=input.household==='alone'?'yes':'unknown'; reason=answer==='yes'?'혼자 거주한다는 답변을 상담 관련 이유로 사용했습니다.':'함께 거주하거나 미답변이어도 다른 위험요인은 확인이 필요합니다.'; }
 else if(key==='careInterest'||key==='screenInterest') { answer=input[key]===true?'yes':'unknown'; reason=answer==='yes'?'해당 상담을 희망한다고 선택했습니다.':'상담 희망 여부를 선택하지 않았습니다.'; }
 else if(key==='vaccine') { answer='unknown'; reason='제공 자료만으로 실제 접종 자격을 판단하지 않습니다.'; }
 else { answer=input[key]; reason=answer==='yes'?`${question}에 예로 답했습니다.`:answer==='no'?`${question}에 아니요로 답했습니다.`:`${question}를 아직 확인하지 못했습니다.`; }
 const status=answer==='yes'?'A':answer==='no'?'C':'B';
 return {status, reason, checks:status==='B'?[question]:['실제 이용 가능 여부와 상담·신청 세부 절차를 담당기관에 확인']};
}
function compare(a,b) { return a.result.status.localeCompare(b.result.status) || Number(b.row['우선안내'])-Number(a.row['우선안내']) || a.row['서비스ID'].localeCompare(b.row['서비스ID']); }
function groupServices(rows,input) {
 const groups = new Map();
 rows.forEach(row=>{ const name=row['서비스명']; if(!groups.has(name)) groups.set(name,[]); groups.get(name).push(row); });
 return [...groups.values()].map(items=>{
  const ordered=[...items].sort((a,b)=>a['서비스ID'].localeCompare(b['서비스ID']));
  const row=ordered.find(r=>r['읍면']===input.town)||ordered[0];
  return {row, rows:ordered, local:row['읍면']===input.town, result:assess(row,input)};
 }).sort(compare);
}
if(typeof module!=='undefined') module.exports={RULES,STATUS,validAge,assess,groupServices};
